// Basic 1
// • Create a variable x as an empty array []. Log this array to your console.
// • Use .push() to add three strings to your array: 'coding', 'dojo', 'rocks'.
// • Use .pop() to remove the final element of your array.
// • Log the final value of x, what is it? {

let x = [];
console.log('x',x);

x.push('coding');
x.push('dojo');
x.push('rocks');
console.log('x',x);

x.pop();
console.log('x',x);
