// Basic 2
// • Create a const called y, and store an empty array there. Log this to your console.
// • Use .push() to add the number 88 to array y.
// • What happened?

const y = [];
console.log('y',y);

y.push(88);
console.log('y',y);
