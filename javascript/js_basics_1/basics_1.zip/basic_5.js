// Basic 5
// • Create a function yell that takes one parameter called string.
// • Make yell return that string in all uppercase.
// • Where could you look to find out more about uppercasing strings in JavaScript?

function yell(string){
  return string.toUpperCase();
}

console.log(yell('keith'));
